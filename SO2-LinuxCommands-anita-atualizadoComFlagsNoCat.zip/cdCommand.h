#include "main.h"

int validateCDCommand(char* path);

void executeCDCommand(char** arguments, int numberOfArguments);
