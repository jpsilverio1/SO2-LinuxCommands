#include "main.h"
#include "pwdCommand.h"

void executePWDCommand()
{
  printf("%s\n",currentDirectory);
}  

int validatePWDCommand() {
  //TODO
  //return INVALID_COMMAND_INPUT;
  return VALID_COMMAND_INPUT;
}

