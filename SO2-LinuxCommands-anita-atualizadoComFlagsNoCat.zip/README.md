Implementation of the following linux commands is C:
* pwd
* wc
* cd
* cat
* echo
* grep

