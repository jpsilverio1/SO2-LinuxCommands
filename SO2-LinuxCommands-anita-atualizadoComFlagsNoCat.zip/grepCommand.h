#include "main.h"

void executeGREPCommandForSingleFile(char* filePath, char* stringToMatch);

void executeGREPCommand(char** arguments, int numberOfPaths);
