#include "main.h"
#include "echoCommand.h"

void executeECHOCommand(char * argument){
  //TODO: validate maybe? Add more stuff?
  printf("%s\n" ,argument); 
}
