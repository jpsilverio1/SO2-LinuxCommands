#include "main.h"

void executeECHOCommand(char * argument);
