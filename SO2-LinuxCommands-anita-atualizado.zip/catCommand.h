#include "main.h"

void executeCATCommand(char ** filePaths, int numberOfPaths);
