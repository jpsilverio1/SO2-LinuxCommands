#include "main.h"

void executeMANCommand(char * commandName);
